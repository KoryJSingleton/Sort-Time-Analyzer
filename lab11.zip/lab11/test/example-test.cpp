#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

TEST_CASE ("Example Test") {
    CHECK_EQ(10, 10);  // Compare the equality of two values
    CHECK_UNARY(true); // When you want to know if something is true
    CHECK_LT(-1, 0);   // Less than. Same as CHECK(-1 < 0)
    CHECK(-1 < 0);     // Generic check for anything
}
