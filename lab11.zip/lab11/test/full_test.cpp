#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include "Array.hpp"
#include "SLList.hpp"

TEST_CASE("Testing Array") {
    SUBCASE("Testing constructors") {
        //Default Constructor
        Array<int> arr;
        CHECK(arr.getLength() == 0);

        //Constructor with array and size
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr2(data, 5);
        CHECK(arr2.getLength() == 5);
        CHECK(arr2[0]==1);
        CHECK(arr2[4]==5);

        //Copy Constructor
        Array<int> arr3(arr2);
        CHECK(arr3.getLength() == 5);
        CHECK(arr3[0]==1);
        CHECK(arr3[4]==5);
    }

    SUBCASE("IndexOf") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        CHECK(arr.indexOf(1) == 0);
        CHECK(arr.indexOf(8) == UINT_MAX);
    }

    SUBCASE("Remove") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        CHECK(arr.remove(0) == true);
        CHECK(arr.getLength() == 4);
        CHECK(arr[0] == 1);
        CHECK(arr[3] == 5);
        CHECK(arr.remove(4) == false);
    }

    SUBCASE("Operator[]") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        arr[0] = 10;
        CHECK(arr[0] == 10);
    }

    SUBCASE("Operator==") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        Array<int> arr2(data, 5);
        CHECK(arr == arr2);
    }

    SUBCASE("Binary Searching") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        CHECK(arr.binarySearch(1) == 1);
        CHECK(arr.binarySearch(8) == UINT_MAX);
    }

    SUBCASE("Selection Sorting") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.selectionSort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }

    SUBCASE("Bubble Sorting") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.bubbleSort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }

    SUBCASE("General Sort") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.sort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }

    SUBCASE("Insertion Sorting") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.insertionSort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }

    SUBCASE("Merge Sorting") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.mergeSort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }

    SUBCASE("Quick Sorting") {
        int data[] = {1, 5, 2, 3, 1};
        Array<int> arr(data, 5);
        arr.quickSort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }
}
TEST_CASE("Testing SLList") {
    SUBCASE("Testing constructors") {
        //Default Constructor
        SLList<int> list;
        CHECK(list.getLength() == 0);

        //Constructor with array and size
        int data[] = {1, 1, 2, 3, 5};
        SLList<int> arr2(data, 5);
        CHECK(arr2.getLength() == 5);
        CHECK(arr2[0]==1);
        CHECK(arr2[4]==5);

        //Copy Constructor
        SLList<int> arr3(arr2);
        CHECK(arr3.getLength() == 5);
        CHECK(arr3[0]==1);
        CHECK(arr3[4]==5);
    }
    SUBCASE("Prepend and uppend") {
        SLList<int> list;
        list.prepend(1);
        list.append(3);
        CHECK(list[0] == 1);
        CHECK(list[1] == 3);
    }
    SUBCASE("Insert") {
        SLList<int> list;
        list.append(1);
        list.append(3);
        CHECK(list.insert(1, 2)== true);
        CHECK(list.getLength() == 3);
        CHECK(list[1] == 2);
    }
    SUBCASE("Remove") {
        int data[] = {1, 1, 2, 3, 5};
        Array<int> arr(data, 5);
        CHECK(arr.remove(0) == true);
        CHECK(arr.getLength() == 4);
        CHECK(arr[0] == 1);
        CHECK(arr[3] == 5);
        CHECK(arr.remove(4) == false);
    }

    SUBCASE("Operator==") {
        int data[] = {1, 1, 2, 3, 5};
        SLList<int> arr(data, 5);
        SLList<int> arr2(data, 5);
        CHECK(arr == arr2);
    }

    SUBCASE("General Sort") {
        int data[] = {1, 5, 2, 3, 1};
        SLList<int> arr(data, 5);
        arr.sort();
        CHECK(arr[0] == 1);
        CHECK(arr[1] == 1);
        CHECK(arr[2] == 2);
        CHECK(arr[3] == 3);
        CHECK(arr[4] == 5);
    }
}