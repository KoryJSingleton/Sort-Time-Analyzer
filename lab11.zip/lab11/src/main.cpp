#include <iostream>
#include <chrono>
#include <fstream>
#include "Array.hpp"
#include "SLList.hpp"

using namespace std;
using namespace chrono;

// Function to generate random arrays
void generateRandomArray(int* tempArray, int size) {
    for (int i = 0; i < size; ++i) {
        tempArray[i] = rand() % 10000;
    }
}

// Function to generate random lists
void generateRandomList(SLList<int>& list, int size) {
    list = SLList<int>();
    for (int i = 0; i < size; ++i) {
        list.append(rand() % 10000);
    }
}

// Function to measure sort performance
template <typename T>
double measureSortTime(T& container, void (T::*sortFunc)()) {
    auto start = high_resolution_clock::now();
    (container.*sortFunc)();
    auto stop = high_resolution_clock::now();
    return duration<double, milli>(stop - start).count();
}

template <typename T, typename Func>
double measureSortTime(T& container, Func sortFunc) {
    auto start = high_resolution_clock::now();
    sortFunc(container);  // Handles lambdas and free functions
    auto stop = high_resolution_clock::now();
    return duration<double, milli>(stop - start).count();
}

int main() {
    ofstream outputFile("performance_data.csv");
    if (!outputFile) {
        cerr << "Error opening file for writing" << endl;
        return 1;
    }

    outputFile << "Size,BubbleSort,QuickSort,MergeSort,LinkedListSort, LLOldSortTime" << endl;

    srand(static_cast<unsigned int>(time(0)));
    
    for (int size = 100; size <= 10000; size += 100) {
        int* tempArray = new int[size];
        generateRandomArray(tempArray, size);

        Array<int> array1(tempArray, size);
        Array<int> array2(tempArray, size);
        Array<int> array3(tempArray, size);
        SLList<int> list;
        generateRandomList(list, size);
        SLList<int> list2(list);

        double bubbleTime = measureSortTime(array1, &Array<int>::bubbleSort);
        double quickTime = measureSortTime(array2, [](Array<int>& arr) { arr.quickSort(); });
        double mergeTime = measureSortTime(array3, [](Array<int>& arr) { arr.mergeSort(); });
        double linkedListSortTime = measureSortTime(list, &SLList<int>::sort);
        double LLoldSortTime = measureSortTime(list2, &SLList<int>::oldSort);
        outputFile << size << "," << bubbleTime << "," << quickTime << "," << mergeTime << "," <<linkedListSortTime << "," << LLoldSortTime<< endl;
        //cout << "Size: " << size << " - Bubble: " << bubbleTime << "s, Selection: " << selectionTime << "s, LinkedListSort: " << linkedListSortTime << "s" << endl;

        delete[] tempArray;
    }

    outputFile.close();
    cout << "Performance data saved to performance_data.csv" << endl;
    return 0;
}
