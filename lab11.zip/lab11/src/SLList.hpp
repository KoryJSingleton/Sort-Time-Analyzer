#ifndef SLLIST_HPP
#define SLLIST_HPP

/** SLList = Singly-Linked List */
template<typename Type>
class SLList {
public:

    /** Empty constructor shall create an empty Linked List. */
    SLList();

    /**
     * Copy the array's values into the list.
     */
    SLList(const Type array[], const unsigned int size);

    /**
     * Do a deep copy of SLL into the this.
     * Note: This one uses a reference to a Singly-Linked List.
     */
    SLList(const SLList<Type>& sll);

    /** Destructor shall free up memory */
    ~SLList();

    /** Return the current length of the list in constant time. */
    unsigned int getLength() const;

    /** Insert at the beginning of the list.*/
    void prepend(const Type& val);

    /** Insert at the end of the list.*/
    void append(const Type& val);

    /**
     * Insert val at position pos.
     * Return true if successfully placed at pos.
     * Otherwise return false.
     */
    bool insert(const unsigned int pos, const Type& val);

    /**
     * Display all the values in order and on the same (ending with
     * a newline). The values comma and space separated.
     * For example, if the list is 3 -> 5 -> 7 -> 9 -> null,
     * display: 3, 5, 7, 9, \n
     */
    void display() const;

    /**
     * Remove the first instance of val
     * Return true if found and removed.
     * Otherwise return false.
     */
    bool remove(const Type& val);

    /* Without validation, retrieves the element pos from the head. */
    Type& operator[](const unsigned int pos);

    /**
     * Supports [] on a const Arrays for read-only access.
     * For example, it is required for:
     * const int ARRAY_SRC[] {1, 2, 3, 4};
     * const SLList<int> CONST_LIST{ARRAY_SRC, 4};
     * int val = CONST_LIST[0]; // requires const [] operator
     */
    const Type& operator[](const unsigned int pos) const;

    /** Returns if the two lists contain the same elements in the
     * same order. Does the comparisons in O(n) time. */
    bool operator==(const SLList<Type>& list) const;

    /**
     * Assignment operator. Clears the old list and deep copy 
     * the values for scrList.
     */
    SLList& operator=(const SLList& srcList);

    /**
     * Sort the linked list. You may use any sort algorithm you wish.
     */
    void sort();
    void oldSort();


private:
    // To Do: Add private members here
    struct Node {
        Type data;
        Node* next;
    };
    Node *head;
    unsigned int mSize;
    static Node* merge(Node* left, Node* right);
    static Node* mergeSort(Node* mhead);
};

/* Since SLList is templated, we include the .cpp
 * Templated classes are not generated until utilized (or explicitly declared.)
 */
#include "SLList.cpp"

#endif
