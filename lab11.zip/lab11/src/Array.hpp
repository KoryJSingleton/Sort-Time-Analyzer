#ifndef ARRAY_HPP
#define ARRAY_HPP

template <typename Type>
class Array {
public:

    /**
     * Default constructor. Creates an empty Array object.
     */
    Array();

    /**
     * Do a deep copy of the array into the list.
     * Note: This one uses a pointer!
     */
    Array(const Type array[], const unsigned int size);

    /**
     * Do a deep copy of the array into the list
     * Note: This one uses a reference to a List!
     */
    Array(const Array<Type> &list);

    /**
     * @return the current length of the array
     */
    unsigned int getLength() const;

    /**
     * Returns the index in the array where value is found.
     * Return INT_MAX from <climits> if value is not in the array.
     */
    unsigned int indexOf(const Type &value) const;

    /**
     * Removes an item at the index by shifting later elements left.
     * Returns true IFF 0 <= index < size.
     */
    bool remove(const unsigned int index);

    /**
     * Returns a reference to the element at specified location pos.
     * No bounds checking is performed. 
     */
    Type& operator[](const unsigned int pos);

    /**
     * Supports [] on a const Arrays for read-only access.
     * For example, it is required for:
     * const int ARRAY_SRC[] {1, 2, 3, 4};
     * const Array<int> CONST_ARRAY{ARRAY_SRC, 4};
     * int val = CONST_ARRAY[0]; // requires const [] operator
     */
    const Type& operator[](const unsigned int pos) const;

    /**
     * Returns if the two lists contain the same elements in the
     * same order.
     */
    bool operator==(const Array<Type> &list) const;

    /** Searches for an element with value value and returns the index
     *  of that data. NOTE: We assume the array is sorted!
     *  Return UINT_MAX from <climits> if value is not in the array.
     */
    unsigned int binarySearch(const Type &value) const;

    /** Runs a selection sort algorithm on the array.
     *  The array shall be ordered from least to greatest
     */
    void selectionSort();

    /** Runs a bubble sort algorithm on the array.
     *  The array shall be ordered from least to greatest
     */
    void bubbleSort();

    /** Runs a insertion sort algorithm on the array.
     *  The array shall be ordered from least to greatest
     */
    void insertionSort();

    /** Runs a quick sort algorithm on the array.
     *  The array shall be ordered from least to greatest
     */
    void quickSort();

    /** Runs a merge sort algorithm on the array.
     *  The array shall be ordered from least to greatest
     */
    void mergeSort();

    /** Runs the sort routing you believe is the best. */
    void sort();

    /**
     * Free any memory used!
     */
    ~Array();

private:
    // Optional helper function for recursive merge sort (use if you want to).
    static void mergeSort(Type list[], const unsigned int size, Type tempArray[]);

    // Optional helper function for the quick sort (use if you want to).
    static unsigned int partition(Type list[], const unsigned int size);

    // Optional helper function for the quick sort (use if you want to).
    static void quickSort(Type list[], const unsigned int size);

    // To Do: Add private members here.
    Type *mArray;
    unsigned int mSize;
};

/* Since Array is templated, we include the .cpp.
 * Templated classes are not implemented until utilized (or explicitly declared).
 */
#include "Array.cpp"

#endif