/* Array is templated, therefore only include the code if it is included from
 * the header file! 
 */
#ifdef ARRAY_HPP

#include <climits>

template <typename Type>
Array<Type>::Array(): mArray(nullptr), mSize(0) {
}

/**
 * Do a deep copy of the array into the list.
 * Note: This one uses a pointer!
 */
template <typename Type>
Array<Type>::Array(const Type array[], const unsigned int size): mSize(size) {
    mArray = new Type[size];
    for (unsigned int i = 0; i < size; ++i) {
        mArray[i] = array[i];
    }
}

/**
 * Do a deep copy of the array into the list
 * Note: This one uses a reference to a List!
 */
template <typename Type>
Array<Type>::Array(const Array<Type> &list):mSize(list.mSize) {
    mArray = new Type[mSize];
    for (unsigned int i = 0; i < list.mSize; ++i) {
        mArray[i] = list[i];
    }

}

template <typename Type>
unsigned int Array<Type>::getLength() const {
    return mSize;
}

template <typename Type>
unsigned int Array<Type>::indexOf(const Type &val) const {
    for (unsigned int i = 0; i <mSize; ++i) {
        if (mArray[i] == val) {
            return i;
        }
    }
    return UINT_MAX; // the largest value an unsigned int can hold
}

// To-Do: Add the definition for remove() here.
template <typename Type>
bool Array<Type>:: remove(const unsigned int index) {
    if (index >= mSize) {
        return false;
    }
    for (unsigned int i = index; i <mSize-1; i++) {
        mArray[i] = mArray[i+1];
    }
    mSize--;
    return true;
}

/** Retrieves the element at position pos */
template <typename Type>
Type& Array<Type>::operator[](const unsigned int pos) {
    return mArray[pos];

}

template <typename Type>
const Type& Array<Type>::operator[](const unsigned int pos) const {
    return mArray[pos];
}

// To-Do: Add the definition for the == operator overload.
template <typename Type>
bool Array<Type>::operator==(const Array<Type> &list) const {
    if (mSize != list.mSize) {
        return false;
    }
    for (unsigned int i =0; i < mSize; ++i) {
        if (mArray[i] != list.mArray[i]) {
            return false;
        }
    }
    return true;
}

template <typename Type>
unsigned int Array<Type>::binarySearch (const Type &value) const {
    unsigned int low = 0;
    unsigned int high = mSize;
    while (low < high) {
        unsigned int mid = (low+high) / 2;
        if (mArray[mid] == value) {
            return mid;
        }
        else if (mArray[mid] < value) {
            low = mid + 1;
        }
        else {
            high = mid;
        }
    }
    return UINT_MAX;
}

template <typename Type>
void Array<Type>::selectionSort() {
    for (unsigned int i = 0; i < mSize; i++) {
        unsigned int index = i;
        for (unsigned int m = i+1; m < mSize; m++){
            if (mArray[m] < mArray[index]) {
                index = m;
            }
        }
        Type holder = mArray[i];
        mArray[i] = mArray[index];
        mArray[index] = holder;
    }
}

template<typename Type>
void Array<Type>::bubbleSort() {
    if (mArray == nullptr || mSize == 0) {
        return;
    }
    for (unsigned int i = 0; i < mSize - 1; i++) {
        for (unsigned int m = 0; m < (mSize - i - 1); m++) {
            if (mArray[m] > mArray[m + 1]) {
                Type holder = mArray[m];
                mArray[m] = mArray[m + 1];
                mArray[m + 1] = holder;
            }
        }
    }
}
template <typename Type>
void Array<Type>::sort() {
    for (unsigned int i = 0; i < mSize - 1; i++) {
        for (unsigned int m = 0; m < (mSize - i - 1); m++) {
            if (mArray[m] > mArray[m + 1]) {
                Type holder = mArray[m];
                mArray[m] = mArray[m + 1];
                mArray[m + 1] = holder;
            }
        }
    }
}

template<typename Type>
void Array<Type>::insertionSort() {
    for (unsigned int i = 1; i < mSize; i++) {
        Type checker = mArray[i];
        unsigned int remainer = i;
        while (remainer > 0 && checker < mArray[remainer-1]) {
            mArray[remainer] = mArray[remainer-1];
            remainer--;
        }
        mArray[remainer] = checker;
    }
}

template <typename Type>
void Array<Type>::mergeSort() {
    Type* temp = new Type[mSize];
    mergeSort(mArray, mSize, temp);
    delete[] temp;
}

template <typename Type>
void Array<Type>:: mergeSort(Type list[], const unsigned int size, Type  temp[]) {
    if (size <= 1) {
        return;
    }
    unsigned int mid = size/2;
    mergeSort(list, mid, temp);
    mergeSort(list+mid, size-mid, temp);
    unsigned int a = 0, b = mid, c = 0;
    while (a < mid && b < size) {
        if (list[a] < list[b]) {
            temp[c++] = list[a++];
        } else {
            temp[c++] = list[b++];
        }

    }
    while (a < mid) {
        temp[c++] = list[a++];
    }
    while (b < size) {
        temp[c++] =list[b++];
    }
    for (unsigned int i =0; i < size; ++i) {
        list[i] = temp[i];
    }
}
template<typename Type>
void Array<Type>::quickSort() {
    quickSort(mArray, mSize);
}
template<typename Type>
void Array<Type>::quickSort(Type list[], const unsigned int size) {
    if (size <= 1) {
        return;
    }
    unsigned int pivot = partition(list, size);
    quickSort(list, pivot);
    quickSort(list +pivot+1, size-pivot -1);
}

template <typename Type>
unsigned int Array<Type>:: partition(Type list[], const unsigned int size) {
    unsigned int mid = size/2;
    Type pivot = list[mid];
    Type temp = list[mid];
    list[mid] = list[size-1];
    list[size-1] = temp;
    unsigned int iterator = 0;
    for (unsigned int i = 0; i < size-1; i++) {
        if (list[i] < pivot) {
            Type holder = list[iterator];
            list[iterator] = list[i];
            list[i] = holder;
            iterator++;
        }
    }
    list[size-1] = list[iterator];
    list[iterator] = pivot;
    return iterator;
}

template <typename Type>
Array<Type>::~Array() {
    delete[] mArray;
}
#endif
