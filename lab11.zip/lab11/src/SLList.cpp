#ifdef SLLIST_HPP
#include <iostream>

/** Constructor: Initializes an empty list */
template<typename Type>
SLList<Type>::SLList() : head(nullptr), mSize(0) {}

/** Constructor: Copies an array into the linked list */
template<typename Type>
SLList<Type>::SLList(const Type array[], const unsigned int arraySize) : head(nullptr), mSize(0) {
    for (unsigned int i = 0; i < arraySize; ++i) {
        append(array[i]);
    }
}

/** Copy Constructor: Deep copy of an existing linked list */
template<typename Type>
SLList<Type>::SLList(const SLList<Type>& sll) : head(nullptr), mSize(0) {
    Node* current = sll.head;
    while (current) {
        append(current->data);
        current = current->next;
    }
}

/** Destructor: Deletes all nodes to free memory */
template<typename Type>
SLList<Type>::~SLList() {
    Node* current = head;
    while (current) {
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
}

/** Return the current length of the Singly Linked List */
template<typename Type>
unsigned int SLList<Type>::getLength() const {
    return mSize;
}

/** Insert at the beginning of the list */
template<typename Type>
void SLList<Type>::prepend(const Type& val) {
    Node* newNode = new Node(val, head);
    head = newNode;
    mSize++;
}

/** Insert at the end of the list */
template<typename Type>
void SLList<Type>::append(const Type& val) {
    Node* newNode = new Node(val, nullptr);
    if (!head) {
        head = newNode;
    } else {
        Node* current = head;
        while (current->next) {
            current = current->next;
        }
        current->next = newNode;
    }
    mSize++;
}

/** Insert at a specific position */
template<typename Type>
bool SLList<Type>::insert(const unsigned int pos, const Type& val) {
    if (pos > mSize) {
        return false;
    }
    if (pos == 0) {
        prepend(val);
        return true;
    }
    Node* newNode = new Node(val, nullptr);
    Node* current = head;
    for (unsigned int i = 0; i < pos - 1; ++i) {
        current = current->next;
    }
    newNode->next = current->next;
    current->next = newNode;
    mSize++;
    return true;
}

/** Remove the first instance of val */
template<typename Type>
bool SLList<Type>::remove(const Type& val) {
    if (!head) {
        return false;
    }
    if (head->data == val) {
        Node* temp = head;
        head = head->next;
        delete temp;
        mSize--;
        return true;
    }
    Node* current = head;
    while (current->next && current->next->data != val) {
        current = current->next;
    }
    if (current->next) {
        Node* temp = current->next;
        current->next = temp->next;
        delete temp;
        mSize--;
        return true;
    }
    return false;
}

template <typename Type>
void SLList<Type>::display() const {
    Node* current = head;
    while (current) {
        std::cout << current->data;
        if (current->next) {
            std::cout << ", ";
        }
        current = current->next;
    }
    std::cout << std::endl;
}
/** Operator [] - Retrieves the element at pos without validation */
template<typename Type>
Type& SLList<Type>::operator[](const unsigned int pos) {
    Node* current = head;
    for (unsigned int i = 0; i < pos; i++) {
        current = current->next;
    }
    return current->data;
}

template <typename Type>
const Type& SLList<Type>::operator[](const unsigned int pos) const {
    Node* current = head;
    for (unsigned int i = 0; i < pos; i++) {
        current = current->next;
    }
    return current->data;
}

/** Operator == - Returns true if two lists are identical */
template<typename Type>
bool SLList<Type>::operator==(const SLList<Type>& list) const {
    if (mSize != list.mSize) {
        return false;
    }
    Node* current1 = head;
    Node* current2 = list.head;
    while (current1 && current2) {
        if (current1->data != current2->data) {
            return false;
        }
        current1 = current1->next;
        current2 = current2->next;
    }
    return true;
}

/** Assignment operator - Clears old list and deep copies the values */
template<typename Type>
SLList<Type>& SLList<Type>::operator=(const SLList<Type>& list) {
    if (this == &list) {
        return *this;
    }
    this->~SLList();
    head = nullptr;
    mSize = 0;
    Node* current = list.head;
    while (current) {
        append(current->data);
        current = current->next;
    }
    return *this;
}

template <typename Type>
void SLList<Type>::sort() {
    head = mergeSort(head);
}

template<typename Type>
typename SLList<Type>::Node* SLList<Type>::merge(Node* left, Node* right) {
    if (!left) {
        return right;
    } else if (!right) {
        return left;
    }
    if (left->data < right-> data) {
        left->next = merge(left->next, right);
        return left;
    } else {
        right->next = merge(left, right->next);
        return right;
    }
}
template<typename Type>
typename SLList<Type>::Node* SLList<Type>::mergeSort(Node* mhead) {
    if (!mhead || !mhead->next) {
        return mhead;
    }
    Node* first =mhead;
    Node* sec = mhead->next;
    while (sec && sec->next) {
        first = first->next;
        sec = sec->next->next;
    }
    Node* mid = first->next;
    first->next = nullptr;
    Node* left = mergeSort(mhead);
    Node* right = mergeSort(mid);
    return merge(left, right);
}
template<typename Type>
void SLList<Type>::oldSort() {
    if (!head || !head->next) {
        return;
    }
    for (Node* i = head; i->next; i = i->next) {
        for (Node* j = i->next; j; j = j->next) {
            if (i->data > j->data) {
                Type temp = i->data;
                i->data = j->data;
                j->data = temp;
            }
        }
    }
}
#endif